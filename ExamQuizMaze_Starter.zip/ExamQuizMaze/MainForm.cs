using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace ExamQuizMaze
{
    public class MainForm : Form
    {
        private Maze maze;
        private Player player;

        private Label labelRoomName;
        private TextBox textBoxDescription;
        private ListBox listBoxRoomItems;
        private ListBox listBoxInventory;
        private TextBox textBoxPaths;

        private Dictionary<string, Button> mapButtons;

        public MainForm()
        {
            this.maze = new Maze();
            this.player = new Player(this.maze.GetStartRoom());
            this.mapButtons = new Dictionary<string, Button>();

            this.BuildGui();
            this.UpdateRoomInfo();
        }

        private void BuildGui()
        {
            this.Text = "Exam Quiz Maze";
            this.Width = 1000;
            this.Height = 620;
            this.StartPosition = FormStartPosition.CenterScreen;

            Label labelMapTitle = new Label();
            labelMapTitle.Text = "Campus Map";
            labelMapTitle.Left = 20;
            labelMapTitle.Top = 15;
            labelMapTitle.Width = 250;
            labelMapTitle.Height = 25;
            labelMapTitle.Font = new Font("Segoe UI", 11, FontStyle.Bold);
            this.Controls.Add(labelMapTitle);

            Panel panelMap = new Panel();
            panelMap.Left = 20;
            panelMap.Top = 45;
            panelMap.Width = 310;
            panelMap.Height = 410;
            panelMap.BorderStyle = BorderStyle.FixedSingle;
            this.Controls.Add(panelMap);

            AddMapButton(panelMap, "Start", 95, 25);
            AddMapButton(panelMap, "OOP Room", 95, 95);
            AddMapButton(panelMap, "Programming Room", 95, 165);
            AddMapButton(panelMap, "Exam Room", 95, 235);
            AddMapButton(panelMap, "Library", 15, 95);
            AddMapButton(panelMap, "Math Room", 175, 95);

            Label labelRoomTitle = new Label();
            labelRoomTitle.Text = "Current Room";
            labelRoomTitle.Left = 360;
            labelRoomTitle.Top = 15;
            labelRoomTitle.Width = 250;
            labelRoomTitle.Height = 25;
            labelRoomTitle.Font = new Font("Segoe UI", 11, FontStyle.Bold);
            this.Controls.Add(labelRoomTitle);

            this.labelRoomName = new Label();
            this.labelRoomName.Left = 360;
            this.labelRoomName.Top = 45;
            this.labelRoomName.Width = 300;
            this.labelRoomName.Height = 30;
            this.labelRoomName.Font = new Font("Segoe UI", 14, FontStyle.Bold);
            this.Controls.Add(this.labelRoomName);

            this.textBoxDescription = new TextBox();
            this.textBoxDescription.Left = 360;
            this.textBoxDescription.Top = 85;
            this.textBoxDescription.Width = 360;
            this.textBoxDescription.Height = 90;
            this.textBoxDescription.Multiline = true;
            this.textBoxDescription.ReadOnly = true;
            this.textBoxDescription.ScrollBars = ScrollBars.Vertical;
            this.Controls.Add(this.textBoxDescription);

            Label labelItems = new Label();
            labelItems.Text = "Items in this room";
            labelItems.Left = 360;
            labelItems.Top = 195;
            labelItems.Width = 250;
            labelItems.Height = 25;
            labelItems.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            this.Controls.Add(labelItems);

            this.listBoxRoomItems = new ListBox();
            this.listBoxRoomItems.Left = 360;
            this.listBoxRoomItems.Top = 225;
            this.listBoxRoomItems.Width = 360;
            this.listBoxRoomItems.Height = 160;
            this.Controls.Add(this.listBoxRoomItems);

            Label labelPaths = new Label();
            labelPaths.Text = "Available paths";
            labelPaths.Left = 360;
            labelPaths.Top = 395;
            labelPaths.Width = 250;
            labelPaths.Height = 25;
            labelPaths.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            this.Controls.Add(labelPaths);

            this.textBoxPaths = new TextBox();
            this.textBoxPaths.Left = 360;
            this.textBoxPaths.Top = 425;
            this.textBoxPaths.Width = 360;
            this.textBoxPaths.Height = 60;
            this.textBoxPaths.Multiline = true;
            this.textBoxPaths.ReadOnly = true;
            this.Controls.Add(this.textBoxPaths);

            Label labelInventory = new Label();
            labelInventory.Text = "Inventory";
            labelInventory.Left = 750;
            labelInventory.Top = 15;
            labelInventory.Width = 180;
            labelInventory.Height = 25;
            labelInventory.Font = new Font("Segoe UI", 11, FontStyle.Bold);
            this.Controls.Add(labelInventory);

            this.listBoxInventory = new ListBox();
            this.listBoxInventory.Left = 750;
            this.listBoxInventory.Top = 45;
            this.listBoxInventory.Width = 200;
            this.listBoxInventory.Height = 340;
            this.Controls.Add(this.listBoxInventory);

            Button buttonNorth = new Button();
            buttonNorth.Text = "North";
            buttonNorth.Left = 360;
            buttonNorth.Top = 505;
            buttonNorth.Width = 80;
            buttonNorth.Click += (sender, args) => MovePlayer('N');
            this.Controls.Add(buttonNorth);

            Button buttonEast = new Button();
            buttonEast.Text = "East";
            buttonEast.Left = 445;
            buttonEast.Top = 505;
            buttonEast.Width = 80;
            buttonEast.Click += (sender, args) => MovePlayer('E');
            this.Controls.Add(buttonEast);

            Button buttonSouth = new Button();
            buttonSouth.Text = "South";
            buttonSouth.Left = 530;
            buttonSouth.Top = 505;
            buttonSouth.Width = 80;
            buttonSouth.Click += (sender, args) => MovePlayer('S');
            this.Controls.Add(buttonSouth);

            Button buttonWest = new Button();
            buttonWest.Text = "West";
            buttonWest.Left = 615;
            buttonWest.Top = 505;
            buttonWest.Width = 80;
            buttonWest.Click += (sender, args) => MovePlayer('W');
            this.Controls.Add(buttonWest);

            Button buttonPick = new Button();
            buttonPick.Text = "Pick";
            buttonPick.Left = 750;
            buttonPick.Top = 405;
            buttonPick.Width = 95;
            buttonPick.Click += (sender, args) => PickSelectedItem();
            this.Controls.Add(buttonPick);

            Button buttonDrop = new Button();
            buttonDrop.Text = "Drop";
            buttonDrop.Left = 855;
            buttonDrop.Top = 405;
            buttonDrop.Width = 95;
            buttonDrop.Click += (sender, args) => DropSelectedItem();
            this.Controls.Add(buttonDrop);

            Button buttonUse = new Button();
            buttonUse.Text = "Use";
            buttonUse.Left = 750;
            buttonUse.Top = 445;
            buttonUse.Width = 200;
            buttonUse.Height = 40;
            buttonUse.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            buttonUse.Click += (sender, args) => UseSelectedItem();
            this.Controls.Add(buttonUse);
        }

        private void AddMapButton(Panel panel, string roomName, int left, int top)
        {
            Button button = new Button();
            button.Text = roomName;
            button.Left = left;
            button.Top = top;
            button.Width = 120;
            button.Height = 45;
            button.Enabled = false;
            panel.Controls.Add(button);
            this.mapButtons.Add(roomName, button);
        }

        private void MovePlayer(char direction)
        {
            this.player.Move(direction);
            this.UpdateRoomInfo();
        }

        private void PickSelectedItem()
        {
            Item selectedItem = this.listBoxRoomItems.SelectedItem as Item;

            if (selectedItem == null)
            {
                MessageBox.Show("Please select an item in the room first.");
                return;
            }

            this.player.PickItem(selectedItem);
            this.UpdateRoomInfo();
        }

        private void DropSelectedItem()
        {
            Item selectedItem = this.listBoxInventory.SelectedItem as Item;

            if (selectedItem == null)
            {
                MessageBox.Show("Please select an item in your inventory first.");
                return;
            }

            this.player.DropItem(selectedItem);
            this.UpdateRoomInfo();
        }

        private void UseSelectedItem()
        {
            Item selectedRoomItem = this.listBoxRoomItems.SelectedItem as Item;
            Item selectedInventoryItem = this.listBoxInventory.SelectedItem as Item;

            if (selectedRoomItem != null)
            {
                selectedRoomItem.Use(this.player);
                this.UpdateRoomInfo();
                return;
            }

            if (selectedInventoryItem != null)
            {
                selectedInventoryItem.Use(this.player);
                this.UpdateRoomInfo();
                return;
            }

            MessageBox.Show("Please select an item first. You can use room items or inventory items.");
        }

        private void UpdateRoomInfo()
        {
            Room currentRoom = this.player.GetCurrentRoom();

            this.labelRoomName.Text = currentRoom.GetName();
            this.textBoxDescription.Text = currentRoom.GetDescription();

            this.listBoxRoomItems.Items.Clear();
            foreach (Item item in currentRoom.GetContent())
            {
                this.listBoxRoomItems.Items.Add(item);
            }

            this.listBoxInventory.Items.Clear();
            foreach (Item item in this.player.GetInventory())
            {
                this.listBoxInventory.Items.Add(item);
            }

            this.textBoxPaths.Text = "";
            foreach (Connection connection in currentRoom.GetConnections())
            {
                string line = connection.GetDirection() + " -> " + connection.GetTargetRoom().GetName();

                if (connection.IsLocked())
                {
                    line += " (needs " + connection.GetRequiredItemName() + ")";
                }

                this.textBoxPaths.Text += line + "\r\n";
            }

            foreach (Button button in this.mapButtons.Values)
            {
                button.BackColor = SystemColors.Control;
                button.ForeColor = SystemColors.ControlText;
            }

            if (this.mapButtons.ContainsKey(currentRoom.GetName()))
            {
                this.mapButtons[currentRoom.GetName()].BackColor = Color.LightGreen;
                this.mapButtons[currentRoom.GetName()].ForeColor = Color.Black;
            }
        }
    }
}
