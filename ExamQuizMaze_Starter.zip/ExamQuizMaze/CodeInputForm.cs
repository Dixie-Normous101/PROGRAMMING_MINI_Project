using System.Drawing;
using System.Windows.Forms;

namespace ExamQuizMaze
{
    public class CodeInputForm : Form
    {
        private TextBox textBoxCode;

        public CodeInputForm(string title)
        {
            this.Text = title;
            this.Width = 330;
            this.Height = 170;
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;

            Label label = new Label();
            label.Text = "Enter the three digit code:";
            label.Left = 20;
            label.Top = 20;
            label.Width = 250;
            label.Height = 25;
            label.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            this.Controls.Add(label);

            this.textBoxCode = new TextBox();
            this.textBoxCode.Left = 20;
            this.textBoxCode.Top = 55;
            this.textBoxCode.Width = 260;
            this.Controls.Add(this.textBoxCode);

            Button buttonOk = new Button();
            buttonOk.Text = "OK";
            buttonOk.Left = 115;
            buttonOk.Top = 90;
            buttonOk.Width = 80;
            buttonOk.Click += (sender, args) =>
            {
                this.DialogResult = DialogResult.OK;
                this.Close();
            };
            this.Controls.Add(buttonOk);

            Button buttonCancel = new Button();
            buttonCancel.Text = "Cancel";
            buttonCancel.Left = 200;
            buttonCancel.Top = 90;
            buttonCancel.Width = 80;
            buttonCancel.Click += (sender, args) =>
            {
                this.DialogResult = DialogResult.Cancel;
                this.Close();
            };
            this.Controls.Add(buttonCancel);
        }

        public string GetEnteredCode()
        {
            return this.textBoxCode.Text;
        }
    }
}
