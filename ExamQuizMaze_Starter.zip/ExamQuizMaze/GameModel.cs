using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace ExamQuizMaze
{
    public class Room
    {
        private string name;
        private string description;
        private bool isExit;
        private List<Item> content;
        private List<Connection> connections;

        public Room(string name, string description, bool isExit)
        {
            this.name = name;
            this.description = description;
            this.isExit = isExit;
            this.content = new List<Item>();
            this.connections = new List<Connection>();
        }

        public string GetName()
        {
            return this.name;
        }

        public string GetDescription()
        {
            return this.description;
        }

        public bool IsExit()
        {
            return this.isExit;
        }

        public List<Item> GetContent()
        {
            return this.content;
        }

        public List<Connection> GetConnections()
        {
            return this.connections;
        }

        public void AddItem(Item item)
        {
            this.content.Add(item);
        }

        public void RemoveItem(Item item)
        {
            this.content.Remove(item);
        }

        public void AddConnection(char direction, Room targetRoom)
        {
            this.connections.Add(new Connection(direction, targetRoom));
        }

        public void AddLockedConnection(char direction, Room targetRoom, string requiredItemName, string lockedMessage)
        {
            this.connections.Add(new Connection(direction, targetRoom, requiredItemName, lockedMessage));
        }

        public Connection FindConnection(char direction)
        {
            foreach (Connection connection in this.connections)
            {
                if (connection.GetDirection() == direction)
                {
                    return connection;
                }
            }

            return null;
        }

        public override string ToString()
        {
            return this.name;
        }
    }

    public class Connection
    {
        private char direction;
        private Room targetRoom;
        private string requiredItemName;
        private string lockedMessage;

        public Connection(char direction, Room targetRoom)
        {
            this.direction = direction;
            this.targetRoom = targetRoom;
            this.requiredItemName = "";
            this.lockedMessage = "";
        }

        public Connection(char direction, Room targetRoom, string requiredItemName, string lockedMessage)
        {
            this.direction = direction;
            this.targetRoom = targetRoom;
            this.requiredItemName = requiredItemName;
            this.lockedMessage = lockedMessage;
        }

        public char GetDirection()
        {
            return this.direction;
        }

        public Room GetTargetRoom()
        {
            return this.targetRoom;
        }

        public string GetRequiredItemName()
        {
            return this.requiredItemName;
        }

        public string GetLockedMessage()
        {
            return this.lockedMessage;
        }

        public bool IsLocked()
        {
            return this.requiredItemName != "";
        }
    }

    public class Player
    {
        private Room currentRoom;
        private List<Item> inventory;

        public Player(Room startRoom)
        {
            this.currentRoom = startRoom;
            this.inventory = new List<Item>();
        }

        public Room GetCurrentRoom()
        {
            return this.currentRoom;
        }

        public List<Item> GetInventory()
        {
            return this.inventory;
        }

        public bool HasItem(string itemName)
        {
            foreach (Item item in this.inventory)
            {
                if (item.GetName() == itemName)
                {
                    return true;
                }
            }

            return false;
        }

        public void AddItem(Item item)
        {
            this.inventory.Add(item);
        }

        public void RemoveItem(Item item)
        {
            this.inventory.Remove(item);
        }

        public bool Move(char direction)
        {
            Connection connection = this.currentRoom.FindConnection(direction);

            if (connection == null)
            {
                MessageBox.Show("There is no path in this direction.");
                return false;
            }

            if (connection.IsLocked() && !this.HasItem(connection.GetRequiredItemName()))
            {
                MessageBox.Show(connection.GetLockedMessage());
                return false;
            }

            this.currentRoom = connection.GetTargetRoom();
            return true;
        }

        public void PickItem(Item item)
        {
            if (!item.IsPickable())
            {
                MessageBox.Show("You cannot pick up " + item.GetName() + ". Use it instead.");
                return;
            }

            this.currentRoom.RemoveItem(item);
            this.inventory.Add(item);
        }

        public void DropItem(Item item)
        {
            this.inventory.Remove(item);
            this.currentRoom.AddItem(item);
        }
    }

    public class Maze
    {
        private Room startRoom;
        private Room examRoom;
        private List<Room> rooms;

        public Maze()
        {
            this.rooms = new List<Room>();
            this.CreateRooms();
        }

        private void CreateRooms()
        {
            Room start = new Room("Start", "You are at the entrance of the university. Find all admissions before entering the final exam.", false);
            Room oopRoom = new Room("OOP Room", "A professor is waiting here with an object-oriented programming question.", false);
            Room mathRoom = new Room("Math Room", "A locked computer asks for a code. Maybe another room contains a hint.", false);
            Room library = new Room("Library", "A quiet room with a hint for the code lock.", false);
            Room programmingRoom = new Room("Programming Room", "This room contains another professor with a programming question.", false);
            Room exam = new Room("Exam Room", "This is the final room. Use the exam paper when you have all admissions.", true);

            start.AddConnection('E', oopRoom);
            oopRoom.AddConnection('W', start);
            oopRoom.AddConnection('S', programmingRoom);

            start.AddLockedConnection('S', library, "Library Key", "The library is locked. You need the Library Key.");
            library.AddConnection('N', start);
            library.AddConnection('E', mathRoom);
            mathRoom.AddConnection('W', library);

            programmingRoom.AddConnection('N', oopRoom);
            programmingRoom.AddLockedConnection('E', exam, "Exam Key", "The exam room is locked. You need the Exam Key.");
            exam.AddConnection('W', programmingRoom);

            start.AddItem(new KeyItem("Library Key", "A key for the library door."));
            oopRoom.AddItem(new ProfessorItem(
                "Professor OOP",
                "A professor who asks an OOP question.",
                new Question("Which keyword is used to override a method in C#?", "virtual", "override", "static", "override"),
                new AdmissionItem("Admission_OOP", "Admission for the OOP exam.")));

            library.AddItem(new HintItem("Code Hint", "The code for the computer is 314."));
            mathRoom.AddItem(new CodeLockItem(
                "Math Code Lock",
                "A computer with a three digit code lock.",
                "314",
                new AdmissionItem("Admission_Math", "Admission for the Math exam.")));

            programmingRoom.AddItem(new KeyItem("Exam Key", "A key for the final exam room."));
            programmingRoom.AddItem(new ProfessorItem(
                "Professor Programming",
                "A professor who asks a programming question.",
                new Question("Which loop is usually used when the number of repetitions is known?", "for", "while", "do-while", "for"),
                new AdmissionItem("Admission_Programming", "Admission for the Programming exam.")));

            exam.AddItem(new ExamPaperItem(
                "Exam Paper",
                "Use this paper to check if you have all admissions.",
                new List<string> { "Admission_OOP", "Admission_Math", "Admission_Programming" }));

            this.startRoom = start;
            this.examRoom = exam;

            this.rooms.Add(start);
            this.rooms.Add(oopRoom);
            this.rooms.Add(mathRoom);
            this.rooms.Add(library);
            this.rooms.Add(programmingRoom);
            this.rooms.Add(exam);
        }

        public Room GetStartRoom()
        {
            return this.startRoom;
        }

        public Room GetExamRoom()
        {
            return this.examRoom;
        }

        public List<Room> GetRooms()
        {
            return this.rooms;
        }
    }

    public class Item
    {
        protected string name;
        protected string description;
        protected bool pickable;

        public Item(string name, string description, bool pickable)
        {
            this.name = name;
            this.description = description;
            this.pickable = pickable;
        }

        public string GetName()
        {
            return this.name;
        }

        public string GetDescription()
        {
            return this.description;
        }

        public bool IsPickable()
        {
            return this.pickable;
        }

        public virtual void Use(Player player)
        {
            MessageBox.Show(this.description);
        }

        public override string ToString()
        {
            return this.name;
        }
    }

    public class KeyItem : Item
    {
        public KeyItem(string name, string description) : base(name, description, true)
        {
        }

        public override void Use(Player player)
        {
            MessageBox.Show("This key opens a locked path. Keep it in your inventory.");
        }
    }

    public class AdmissionItem : Item
    {
        public AdmissionItem(string name, string description) : base(name, description, true)
        {
        }

        public override void Use(Player player)
        {
            MessageBox.Show("This is one of your exam admissions. Keep it in your inventory.");
        }
    }

    public class HintItem : Item
    {
        public HintItem(string name, string description) : base(name, description, false)
        {
        }

        public override void Use(Player player)
        {
            MessageBox.Show(this.description);
        }
    }

    public class ProfessorItem : Item
    {
        private Question question;
        private AdmissionItem rewardItem;
        private bool alreadySolved;

        public ProfessorItem(string name, string description, Question question, AdmissionItem rewardItem) : base(name, description, false)
        {
            this.question = question;
            this.rewardItem = rewardItem;
            this.alreadySolved = false;
        }

        public override void Use(Player player)
        {
            if (this.alreadySolved)
            {
                MessageBox.Show("You already solved this professor's question.");
                return;
            }

            QuizForm quizForm = new QuizForm(this.name, this.question);
            DialogResult result = quizForm.ShowDialog();

            if (result == DialogResult.OK)
            {
                player.AddItem(this.rewardItem);
                this.alreadySolved = true;
                MessageBox.Show("Correct! You received: " + this.rewardItem.GetName());
            }
            else
            {
                MessageBox.Show("Wrong answer. Try again later.");
            }
        }
    }

    public class CodeLockItem : Item
    {
        private string code;
        private AdmissionItem rewardItem;
        private bool alreadySolved;

        public CodeLockItem(string name, string description, string code, AdmissionItem rewardItem) : base(name, description, false)
        {
            this.code = code;
            this.rewardItem = rewardItem;
            this.alreadySolved = false;
        }

        public override void Use(Player player)
        {
            if (this.alreadySolved)
            {
                MessageBox.Show("This code lock is already solved.");
                return;
            }

            CodeInputForm codeInputForm = new CodeInputForm(this.name);
            DialogResult result = codeInputForm.ShowDialog();

            if (result == DialogResult.OK && codeInputForm.GetEnteredCode() == this.code)
            {
                player.AddItem(this.rewardItem);
                this.alreadySolved = true;
                MessageBox.Show("Correct code! You received: " + this.rewardItem.GetName());
            }
            else
            {
                MessageBox.Show("Wrong code.");
            }
        }
    }

    public class ExamPaperItem : Item
    {
        private List<string> requiredAdmissions;

        public ExamPaperItem(string name, string description, List<string> requiredAdmissions) : base(name, description, false)
        {
            this.requiredAdmissions = requiredAdmissions;
        }

        public override void Use(Player player)
        {
            List<string> missingAdmissions = new List<string>();

            foreach (string admission in this.requiredAdmissions)
            {
                if (!player.HasItem(admission))
                {
                    missingAdmissions.Add(admission);
                }
            }

            if (missingAdmissions.Count == 0)
            {
                MessageBox.Show("Congratulations! You have all admissions and passed the final exam!");
            }
            else
            {
                string message = "You cannot start the final exam yet. Missing admissions:\n";

                foreach (string admission in missingAdmissions)
                {
                    message += "- " + admission + "\n";
                }

                MessageBox.Show(message);
            }
        }
    }

    public class Question
    {
        private string questionText;
        private string answerA;
        private string answerB;
        private string answerC;
        private string correctAnswer;

        public Question(string questionText, string answerA, string answerB, string answerC, string correctAnswer)
        {
            this.questionText = questionText;
            this.answerA = answerA;
            this.answerB = answerB;
            this.answerC = answerC;
            this.correctAnswer = correctAnswer;
        }

        public string GetQuestionText()
        {
            return this.questionText;
        }

        public string GetAnswerA()
        {
            return this.answerA;
        }

        public string GetAnswerB()
        {
            return this.answerB;
        }

        public string GetAnswerC()
        {
            return this.answerC;
        }

        public bool IsCorrect(string answer)
        {
            return answer == this.correctAnswer;
        }
    }
}
