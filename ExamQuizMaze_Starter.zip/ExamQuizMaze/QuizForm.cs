using System.Drawing;
using System.Windows.Forms;

namespace ExamQuizMaze
{
    public class QuizForm : Form
    {
        private Question question;

        public QuizForm(string title, Question question)
        {
            this.question = question;

            this.Text = title;
            this.Width = 440;
            this.Height = 250;
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;

            Label labelQuestion = new Label();
            labelQuestion.Text = question.GetQuestionText();
            labelQuestion.Left = 20;
            labelQuestion.Top = 20;
            labelQuestion.Width = 380;
            labelQuestion.Height = 60;
            labelQuestion.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            this.Controls.Add(labelQuestion);

            Button buttonA = new Button();
            buttonA.Text = question.GetAnswerA();
            buttonA.Left = 20;
            buttonA.Top = 90;
            buttonA.Width = 380;
            buttonA.Height = 30;
            buttonA.Click += (sender, args) => CheckAnswer(question.GetAnswerA());
            this.Controls.Add(buttonA);

            Button buttonB = new Button();
            buttonB.Text = question.GetAnswerB();
            buttonB.Left = 20;
            buttonB.Top = 125;
            buttonB.Width = 380;
            buttonB.Height = 30;
            buttonB.Click += (sender, args) => CheckAnswer(question.GetAnswerB());
            this.Controls.Add(buttonB);

            Button buttonC = new Button();
            buttonC.Text = question.GetAnswerC();
            buttonC.Left = 20;
            buttonC.Top = 160;
            buttonC.Width = 380;
            buttonC.Height = 30;
            buttonC.Click += (sender, args) => CheckAnswer(question.GetAnswerC());
            this.Controls.Add(buttonC);
        }

        private void CheckAnswer(string answer)
        {
            if (this.question.IsCorrect(answer))
            {
                this.DialogResult = DialogResult.OK;
            }
            else
            {
                this.DialogResult = DialogResult.Cancel;
            }

            this.Close();
        }
    }
}
